#include <iostream>
using namespace std;

int main()
{
    int array[4] = {10,20,30,40};
    cout<<array[0]<<endl;
    return 0;
}