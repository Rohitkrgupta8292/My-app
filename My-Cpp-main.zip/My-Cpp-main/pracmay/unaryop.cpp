#include <iostream>
using namespace std;

int main()
{
    int a=10;
    int b;

    int c=10;
    int d;

    d=c++; 

    b=++a;

    cout<<a<<" "<<b<<endl;
    cout<<c<<" "<<d<<endl;


}