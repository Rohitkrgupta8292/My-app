#include <iostream>
using namespace std;

int main()
{
    int n;
    cout<<"N: ";
    cin>>n;

    while(n>0)
    {
        cout<<n<<endl;
        cout<<"N: ";
        cin>>n;
    }

    return 0;
}
