#include <bits/stdc++.h>
//#include <algorithm>
using namespace std;

int main()
{
    string s1 = "rohitgupta";

    sort(s1.begin(), s1.end());
    cout<<s1<<endl;
    return 0;
}