#include <bits/stdc++.h>
using namespace std;

void print(string str)
{
    for(int i=0; i<10; i++)
    {
        cout<<str<<endl;
    }
    cout<<endl;
}

int main(){

    print("rohit");
    return 0;
}